Launch archive
